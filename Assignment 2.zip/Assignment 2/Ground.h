#pragma once

#define GROUNDSIZE 100
#define GROUND_QUADSIZE 5
void render_ground(void);
void test_render(int);
void drawOrigin(void);
void render_grid(void);
void render_road(void);